# EDA2-Estagio
Assuntos segundo estagio EDA.
